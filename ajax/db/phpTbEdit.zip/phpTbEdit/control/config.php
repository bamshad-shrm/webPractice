<?php
	 
	$servername = "localhost";
	$username = "bamshads_bamshad";
	$password = "Bamshad_5155658";
	$dbname = "bamshads_php_test";
	 	 
?>
