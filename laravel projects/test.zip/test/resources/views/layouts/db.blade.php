<html>
<head>
 	@include('includes.head')
</head>
<body>

	@include('includes.menu')
<div class="jumbotron">
	<div class="container text-center">

	@include('includes.submitContainer')

	@include('includes.dbContainer')  

	</div>
</div>


	@include('includes.footer')


</body>
</html>
