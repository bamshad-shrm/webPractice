<html>
<head>
 	@include('includes.head')
</head>
<body>

	@include('includes.menu')

	@include('includes.container')  

	@include('includes.footer')

</body>
</html>
