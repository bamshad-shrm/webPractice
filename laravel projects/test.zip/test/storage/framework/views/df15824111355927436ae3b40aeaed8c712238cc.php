<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="http://bamshad-shm.com/">Home</a>
    </div>
    <ul class="nav navbar-nav">
		<?php echo $__env->make(config('laravel-menu.views.bootstrap-items'), ['items' => $MyNavBar->roots()], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </ul>
  </div>
</nav>
