<style>
	/* Add a gray background color and some padding to the footer */
	footer {
		background-color: #f2f2f2;
		padding: 25px;
    }

</style>
<footer class="container-fluid text-center">
	<p>bamshad.shm@gmail.com</p>
</footer>
