<nav class="navbar">
  <ul class="horizontal-navbar">
    <?php echo $__env->make('custom-menu-items', ['items' => $MyNavBar->roots()], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </ul>
</nav><!--/nav-->
