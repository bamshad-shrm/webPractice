

		<ul class="list-group">
			<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 	<li class="list-group-item"><a href="<?php echo e($link->url); ?>" target="_blank"><?php echo e($link->title); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>



