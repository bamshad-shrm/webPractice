<title>My Laravel Example Site</title>
<meta name="description" content="An example site for learning Laravel.">
