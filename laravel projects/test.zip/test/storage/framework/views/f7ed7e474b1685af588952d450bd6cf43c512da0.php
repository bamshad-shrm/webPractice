<html>
<head>
 	<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>

	<?php echo $__env->make('includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="jumbotron">
	<div class="container text-center">

	<?php echo $__env->make('includes.submitContainer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('includes.dbContainer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  

	</div>
</div>


	<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
