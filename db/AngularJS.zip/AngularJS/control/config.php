<?php 
$DB_HOST = 'localhost';
$DB_USER = 'bamshads_bamshad';
$DB_PASS = 'Bamshad_5155658';
$DB_NAME = 'bamshads_angularjs';
?>
